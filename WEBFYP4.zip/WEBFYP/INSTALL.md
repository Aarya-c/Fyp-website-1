# Installation Guide

This guide will help you set up and run the OWASP Security Scanner application.

## Prerequisites

- Node.js (v12 or higher)
- NPM (v6 or higher)

## Installation Steps

### Windows

1. Double-click on `setup.bat`
2. If Node.js is not installed, the script will prompt you to install it
3. After Node.js is installed, run `setup.bat` again
4. The script will install all dependencies

### Linux/Mac

1. Open terminal in the project directory
2. Make the setup script executable:
   ```
   chmod +x setup.sh
   ```
3. Run the setup script:
   ```
   ./setup.sh
   ```
4. The script will check for Node.js and install dependencies

### Manual Installation

If the setup scripts don't work for you:

1. Install Node.js from https://nodejs.org/
2. Open terminal/command prompt in the project directory
3. Run:
   ```
   npm install
   ```

## Running the Application

### Development Mode

```
npm run dev
```

This will start the application in development mode with auto-restart when files change.

### Production Mode

```
npm start
```

This will start the application in production mode.

## Accessing the Application

Once started, you can access the application at:

```
http://localhost:3000
```

## Troubleshooting

- **Error: ENOENT: no such file or directory, open 'database/scanner.db'** - Create the `database` directory in the project root if it doesn't exist.

- **Error: listen EADDRINUSE: address already in use :::3000** - Port 3000 is already in use. Edit `server.js` to change the port number.

- **Error: Cannot find module** - Try running `npm install` again.

## Additional Information

Refer to the README.md file for more details about the application features and structure. 