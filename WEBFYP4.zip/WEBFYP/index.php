<?php
// Just to test if PHP is working
echo "PHP is working!";
echo "<br>Try accessing the application directly at: <a href='http://localhost:8080'>http://localhost:8080</a>";
?> 