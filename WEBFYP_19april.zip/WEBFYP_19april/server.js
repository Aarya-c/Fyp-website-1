const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');
const nodemailer = require('nodemailer');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

// Import routers
const authRoutes = require('./routes/auth');
const scanRoutes = require('./routes/scan');
const reportRoutes = require('./routes/report');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Database setup
const db = new sqlite3.Database('./database/scanner.db', (err) => {
  if (err) {
    console.error('Error connecting to database:', err.message);
  } else {
    console.log('Connected to the SQLite database');
    initializeDatabase();
  }
});

// Function to initialize database tables
function initializeDatabase() {
  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    email TEXT UNIQUE NOT NULL,
    password TEXT,
    google_id TEXT,
    profile_picture TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Scans table
  db.run(`CREATE TABLE IF NOT EXISTS scans (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    url TEXT NOT NULL,
    scan_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // Reports table
  db.run(`CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY,
    scan_id TEXT NOT NULL,
    report_data TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (scan_id) REFERENCES scans (id)
  )`);

  console.log('Database tables initialized');
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
  secret: 'owasp-scan-tool-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 3600000 } // 1 hour
}));

// Initialize Passport
app.use(passport.initialize());
app.use(passport.session());

// Google OAuth Strategy
passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID || '123456789-example.apps.googleusercontent.com',
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || 'GOOGLE_CLIENT_SECRET',
    callbackURL: 'http://localhost:3000/auth/google/callback'
  },
  function(accessToken, refreshToken, profile, done) {
    // Check if the user exists in the database
    db.get('SELECT * FROM users WHERE google_id = ? OR email = ?', 
      [profile.id, profile.emails[0].value], (err, user) => {
        if (err) {
          return done(err);
        }
        
        if (user) {
          // If user exists but Google ID is not set, update it
          if (!user.google_id) {
            db.run('UPDATE users SET google_id = ?, profile_picture = ? WHERE email = ?', 
              [profile.id, profile.photos[0].value, profile.emails[0].value]);
          }
          return done(null, user);
        } else {
          // Create a new user
          db.run('INSERT INTO users (username, email, google_id, profile_picture) VALUES (?, ?, ?, ?)', 
            [profile.displayName, profile.emails[0].value, profile.id, profile.photos[0].value], 
            function(err) {
              if (err) {
                return done(err);
              }
              // Get the newly created user
              db.get('SELECT * FROM users WHERE id = ?', [this.lastID], (err, newUser) => {
                return done(null, newUser);
              });
            });
        }
      });
  }
));

// Serialize user to the session
passport.serializeUser((user, done) => {
  done(null, user.id);
});

// Deserialize user from the session
passport.deserializeUser((id, done) => {
  db.get('SELECT * FROM users WHERE id = ?', [id], (err, user) => {
    done(err, user);
  });
});

// Serve static files
app.use(express.static(path.join(__dirname, 'static')));

// Make db available to routes
app.use((req, res, next) => {
  req.db = db;
  next();
});

// Routes
app.use('/auth', authRoutes);
app.use('/scan', scanRoutes);
app.use('/report', reportRoutes);

// Google OAuth routes
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback', 
  passport.authenticate('google', { failureRedirect: '/auth/login' }),
  function(req, res) {
    // Save user ID and username in session
    req.session.userId = req.user.id;
    req.session.username = req.user.username || req.user.email.split('@')[0];
    // Successful authentication, redirect to dashboard
    res.redirect('/dashboard');
  }
);

// Home route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'templates/index.html'));
});

// Dashboard route (protected)
app.get('/dashboard', (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/auth/login');
  }
  res.sendFile(path.join(__dirname, 'templates/dashboard.html'));
});

// Reports route (protected)
app.get('/reports', (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/auth/login');
  }
  
  // If there's a scan parameter, show the detailed report
  if (req.query.scan) {
    res.sendFile(path.join(__dirname, 'templates/reports.html'));
  } else {
    // Otherwise show the list of all reports
    res.sendFile(path.join(__dirname, 'templates/scanlist.html'));
  }
});

// Keep this route as a redirect to the reports page
app.get('/scanlist', (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/auth/login');
  }
  res.redirect('/reports');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

// Export db for use in other files
module.exports = { db }; 