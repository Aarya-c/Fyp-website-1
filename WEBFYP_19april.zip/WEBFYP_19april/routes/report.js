const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

// Create PDF
function createPDF(reportData, url, filepath, callback) {
  const doc = new PDFDocument();
  const stream = fs.createWriteStream(filepath);
  doc.pipe(stream);

  doc.fontSize(20).text('OWASP Top 10 Vulnerability Scan Report', { align: 'center' });
  doc.moveDown();
  doc.fontSize(12).text(`URL: ${url}`);
  doc.text(`Generated on: ${new Date().toLocaleString()}`);
  doc.moveDown();
  doc.fontSize(16).text('Findings Summary', { underline: true });

  Object.values(reportData.vulnerabilities).forEach(vuln => {
    doc.moveDown().fontSize(14).text(vuln.name);
    doc.fontSize(12).text(`Status: ${vuln.found ? 'Vulnerable' : 'Not Vulnerable'}`);
    if (vuln.details) doc.text(`Details: ${vuln.details}`);
    if (vuln.recommendation) doc.text(`Recommendation: ${vuln.recommendation}`);
  });

  doc.moveDown().fontSize(16).text('Recommendations', { underline: true });
  doc.fontSize(12).text(reportData.recommendations);
  doc.moveDown().fontSize(16).text('Conclusion', { underline: true });
  doc.fontSize(12).text(reportData.conclusion);

  doc.end();
  stream.on('finish', callback);
}

// Send Email
async function sendEmail(to, filepath, url, res) {
  try {
    const testAccount = await nodemailer.createTestAccount();
    const transporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: {
        user: testAccount.user,
        pass: testAccount.pass
      }
    });

    const info = await transporter.sendMail({
      from: 'OWASP Scanner <scanner@example.com>',
      to,
      subject: 'OWASP Vulnerability Report',
      text: `Attached is the scan report for ${url}`,
      attachments: [{ filename: 'report.pdf', path: filepath }]
    });

    fs.unlinkSync(filepath);
    res.json({ success: true, message: 'Report sent successfully', previewUrl: nodemailer.getTestMessageUrl(info) });
  } catch (err) {
    if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
    res.status(500).json({ success: false, message: 'Failed to send report' });
  }
}

// Share Report by Scan ID
router.post('/share/scan/:scanId', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ success: false, message: 'Authentication required' });
  const { scanId } = req.params;
  const { recipientEmail } = req.body;
  if (!recipientEmail) return res.status(400).json({ success: false, message: 'Recipient email is required' });

  const db = req.db;
  db.get(`SELECT r.*, s.url FROM reports r JOIN scans s ON r.scan_id = s.id WHERE s.id = ? AND s.user_id = ?`,
    [scanId, req.session.userId], (err, report) => {
      if (err || !report) return res.status(404).json({ success: false, message: 'Report not found' });

      const reportData = JSON.parse(report.report_data);
      const filepath = path.join(__dirname, '..', 'temp', `report_${Date.now()}.pdf`);
      if (!fs.existsSync(path.dirname(filepath))) fs.mkdirSync(path.dirname(filepath));

      createPDF(reportData, report.url, filepath, () => {
        sendEmail(recipientEmail, filepath, report.url, res);
      });
    });
});

// Download PDF by Scan ID
router.get('/download/pdf/scan/:scanId', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ success: false, message: 'Authentication required' });
  const { scanId } = req.params;
  const db = req.db;

  db.get(`SELECT r.*, s.url FROM reports r JOIN scans s ON r.scan_id = s.id WHERE s.id = ? AND s.user_id = ?`,
    [scanId, req.session.userId], (err, report) => {
      if (err || !report) return res.status(404).json({ success: false, message: 'Report not found' });

      const reportData = JSON.parse(report.report_data);
      res.setHeader('Content-disposition', `attachment; filename=owasp_scan_report_${Date.now()}.pdf`);
      res.setHeader('Content-type', 'application/pdf');

      const doc = new PDFDocument();
      doc.pipe(res);

      doc.fontSize(20).text('OWASP Top 10 Vulnerability Scan Report', { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`URL: ${report.url}`);
      doc.moveDown();
      doc.text(`Report Date: ${new Date().toLocaleString()}`);
      doc.moveDown();

      doc.fontSize(16).text('Findings Summary', { underline: true });
      doc.moveDown();
      Object.keys(reportData.vulnerabilities).forEach(vulnType => {
        const vuln = reportData.vulnerabilities[vulnType];
        doc.fontSize(14).text(vuln.name);
        doc.fontSize(12).text(`Status: ${vuln.found ? 'Vulnerable' : 'Not Vulnerable'}`);
        if (vuln.details) doc.text(`Details: ${vuln.details}`);
        if (vuln.recommendation) doc.text(`Recommendation: ${vuln.recommendation}`);
        doc.moveDown();
      });

      doc.fontSize(16).text('Recommendations', { underline: true });
      doc.moveDown();
      doc.fontSize(12).text(reportData.recommendations);
      doc.moveDown();
      doc.fontSize(16).text('Conclusion', { underline: true });
      doc.moveDown();
      doc.fontSize(12).text(reportData.conclusion);
      doc.end();
    });
});

// Download JSON by Scan ID
router.get('/download/json/scan/:scanId', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ success: false, message: 'Authentication required' });
  const { scanId } = req.params;
  const db = req.db;

  db.get(`SELECT r.*, s.url FROM reports r JOIN scans s ON r.scan_id = s.id WHERE s.id = ? AND s.user_id = ?`,
    [scanId, req.session.userId], (err, report) => {
      if (err || !report) return res.status(404).json({ success: false, message: 'Report not found' });

      const reportData = JSON.parse(report.report_data);
      reportData.url = report.url;
      reportData.reportId = report.id;
      reportData.scanId = report.scan_id;
      reportData.exportDate = new Date().toISOString();

      const filename = `owasp_scan_report_${Date.now()}.json`;
      res.setHeader('Content-disposition', `attachment; filename=${filename}`);
      res.setHeader('Content-type', 'application/json');
      res.json(reportData);
    });
});

// Get Report by Scan ID
router.get('/scan/:scanId', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ success: false, message: 'Authentication required' });
  const { scanId } = req.params;
  const db = req.db;

  db.get(`SELECT r.*, s.url FROM reports r JOIN scans s ON r.scan_id = s.id WHERE s.id = ? AND s.user_id = ?`,
    [scanId, req.session.userId], (err, report) => {
      if (err) return res.status(500).json({ success: false, message: 'Database error' });
      if (!report) return res.status(404).json({ success: false, message: 'Report not found' });

      const reportData = JSON.parse(report.report_data);
      reportData.url = report.url;
      res.json({ success: true, report: reportData });
    });
});

module.exports = router;
