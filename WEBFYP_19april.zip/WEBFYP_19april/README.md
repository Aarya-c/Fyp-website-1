# OWASP Top 10 Website Security Scanner

This application is a web-based tool that scans websites for security vulnerabilities based on the OWASP Top 10 list. It provides detailed reports with remediation recommendations and allows users to download or share reports via email.

## Features

- Real-time scanning of websites for OWASP Top 10 vulnerabilities
- User authentication and scan history
- Detailed vulnerability reports with recommendations
- PDF report generation for download
- Email sharing of reports
- Responsive design for desktop and mobile devices

## Technology Stack

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Node.js, Express.js
- **Database**: SQLite
- **Authentication**: Session-based with bcrypt password hashing
- **Report Generation**: PDFKit
- **Email**: Nodemailer

## Requirements

- Node.js (v12 or higher)
- NPM (v6 or higher)

## Installation

### Windows

1. Clone the repository:
   ```
   git clone <repository-url>
   cd owasp-scanner
   ```

2. Run the setup script:
   ```
   setup.bat
   ```

### Linux/Mac

1. Clone the repository:
   ```
   git clone <repository-url>
   cd owasp-scanner
   ```

2. Make the setup script executable and run it:
   ```
   chmod +x setup.sh
   ./setup.sh
   ```

### Manual Setup

If the setup scripts don't work for you:

1. Ensure Node.js is installed
2. Install dependencies:
   ```
   npm install
   ```

## Running the Application

1. Start the server in production mode:
   ```
   npm start
   ```

2. For development with automatic reloading:
   ```
   npm run dev
   ```

3. Access the application in your web browser at:
   ```
   http://localhost:3000
   ```

## Project Structure

- **server.js**: Main application entry point
- **routes/**: API routes
  - **auth.js**: Authentication routes
  - **scan.js**: Scanning functionality
  - **report.js**: Report generation and sharing
- **scripts/**: Utility scripts
  - **scanner.js**: OWASP vulnerability scanning logic
- **templates/**: HTML templates
  - **index.html**: Landing page
  - **login.html**: Login page
  - **register.html**: Registration page
  - **dashboard.html**: User dashboard
  - **reports.html**: Report viewing page
- **static/**: Static assets
  - **css/**: Stylesheets
  - **js/**: Client-side JavaScript
- **database/**: SQLite database file

## Database Schema

The application uses SQLite with the following tables:

- **users**: User account information
  - id: Primary key
  - username: User's display name
  - email: User's email (unique)
  - password: Hashed password
  - created_at: Account creation timestamp

- **scans**: Scan history and status
  - id: Primary key (UUID)
  - user_id: Foreign key to users table
  - url: Website URL that was scanned
  - scan_date: Date and time of the scan
  - status: Current status (pending, in_progress, completed, failed)

- **reports**: Scan results and report data
  - id: Primary key (UUID)
  - scan_id: Foreign key to scans table
  - report_data: JSON string containing the scan results
  - created_at: Report creation timestamp

## OWASP Top 10 Vulnerabilities

The scanner checks for the following OWASP Top 10 vulnerabilities:

1. Injection
2. Broken Authentication
3. Sensitive Data Exposure
4. XML External Entities (XXE)
5. Broken Access Control
6. Security Misconfiguration
7. Cross-Site Scripting (XSS)
8. Insecure Deserialization
9. Using Components with Known Vulnerabilities
10. Insufficient Logging & Monitoring

## Troubleshooting

- **Database issues**: If you encounter database errors, check that the `database` directory exists and is writable.
- **Email sending issues**: The application uses Ethereal email for testing purposes. Check the console for preview URLs.
- **Port conflicts**: If port 3000 is already in use, you can modify the PORT variable in server.js.

## License

This project is open source and available under the MIT License.

## Disclaimer

This tool is for educational purposes only. Do not use it to scan websites without proper authorization. The scanner performs passive checks only and does not attempt to exploit vulnerabilities. 