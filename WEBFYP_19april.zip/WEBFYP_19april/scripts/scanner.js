const axios = require('axios');
const cheerio = require('cheerio');
const url = require('url');

/**
 * Perform OWASP Top 10 vulnerabilities scan on a URL
 * @param {string} targetUrl - URL to scan
 * @returns {Object} Scan results
 */
async function performOWASPScan(targetUrl) {
  console.log(`Starting scan for: ${targetUrl}`);
  
  // Parse URL for various tests
  const parsedUrl = new URL(targetUrl);
  
  // Initialize results object
  const results = {
    url: targetUrl,
    scanDate: new Date().toISOString(),
    vulnerabilities: {
      injection: {
        id: 'A1:2021',
        name: 'Injection',
        found: false,
        details: null,
        recommendation: 'Use parameterized queries, input validation, and escape special characters.'
      },
      authentication: {
        id: 'A2:2021',
        name: 'Broken Authentication',
        found: false, 
        details: null,
        recommendation: 'Implement multi-factor authentication, strong password policies, and account lockout mechanisms.'
      },
      dataExposure: {
        id: 'A3:2021',
        name: 'Sensitive Data Exposure',
        found: false,
        details: null,
        recommendation: 'Use encryption for sensitive data, implement proper key management, and disable caching of sensitive information.'
      },
      xxe: {
        id: 'A4:2021',
        name: 'XML External Entities (XXE)',
        found: false,
        details: null,
        recommendation: 'Disable XML external entity processing, implement input validation, and use less complex data formats like JSON.'
      },
      accessControl: {
        id: 'A5:2021',
        name: 'Broken Access Control',
        found: false,
        details: null,
        recommendation: 'Implement proper access controls, deny by default, and enforce record ownership.'
      },
      securityMisconfiguration: {
        id: 'A6:2021',
        name: 'Security Misconfiguration',
        found: false,
        details: null,
        recommendation: 'Implement secure configuration, remove unused features, update software regularly, and use security headers.'
      },
      xss: {
        id: 'A7:2021',
        name: 'Cross-Site Scripting (XSS)',
        found: false,
        details: null,
        recommendation: 'Use content security policy, output encoding, and frameworks that automatically escape XSS.'
      },
      insecureDeserialization: {
        id: 'A8:2021',
        name: 'Insecure Deserialization',
        found: false,
        details: null,
        recommendation: 'Do not accept serialized objects from untrusted sources and implement integrity checks.'
      },
      vulnerableComponents: {
        id: 'A9:2021',
        name: 'Using Components with Known Vulnerabilities',
        found: false,
        details: null,
        recommendation: 'Remove unused dependencies, scan for vulnerabilities regularly, and monitor security bulletins.'
      },
      logging: {
        id: 'A10:2021',
        name: 'Insufficient Logging & Monitoring',
        found: false,
        details: null,
        recommendation: 'Implement logging for security events, ensure adequate monitoring, and create an incident response plan.'
      }
    },
    recommendations: '',
    conclusion: ''
  };
  
  try {
    // Get the main page
    const response = await axios.get(targetUrl, {
      headers: {
        'User-Agent': 'OWASP Scanner/1.0 (Educational Purpose Only)'
      },
      timeout: 10000,
      maxRedirects: 5
    });
    
    const $ = cheerio.load(response.data);
    const responseHeaders = response.headers;
    
    // Store headers for analysis
    const securityHeaders = {
      'Content-Security-Policy': responseHeaders['content-security-policy'],
      'X-XSS-Protection': responseHeaders['x-xss-protection'],
      'X-Frame-Options': responseHeaders['x-frame-options'],
      'X-Content-Type-Options': responseHeaders['x-content-type-options'],
      'Strict-Transport-Security': responseHeaders['strict-transport-security'],
      'Referrer-Policy': responseHeaders['referrer-policy']
    };
    
    // 1. Check for Injection vulnerabilities
    const forms = $('form');
    if (forms.length > 0) {
      const inputsWithoutValidation = [];
      forms.each((i, form) => {
        const inputs = $(form).find('input[type="text"], input[type="search"], textarea');
        inputs.each((j, input) => {
          if (!$(input).attr('pattern') && !$(input).attr('required')) {
            inputsWithoutValidation.push($(input).attr('name') || 'unnamed-input');
          }
        });
      });
      
      if (inputsWithoutValidation.length > 0) {
        results.vulnerabilities.injection.found = true;
        results.vulnerabilities.injection.details = `Found ${inputsWithoutValidation.length} inputs without proper validation: ${inputsWithoutValidation.join(', ')}`;
      }
    }
    
    // 2. Check for Broken Authentication
    const hasLoginForm = $('form').filter((i, form) => {
      return $(form).find('input[type="password"]').length > 0;
    }).length > 0;
    
    if (hasLoginForm) {
      // Check if login form is served over HTTPS
      if (parsedUrl.protocol !== 'https:') {
        results.vulnerabilities.authentication.found = true;
        results.vulnerabilities.authentication.details = 'Login form detected on non-HTTPS connection';
      }
      
      // Look for remember me functionality
      const hasRememberMe = $('input[type="checkbox"]').filter((i, checkbox) => {
        const label = $(checkbox).attr('id') ? $(`label[for="${$(checkbox).attr('id')}"]`).text().toLowerCase() : '';
        return label.includes('remember') || $(checkbox).attr('name')?.toLowerCase().includes('remember');
      }).length > 0;
      
      if (hasRememberMe) {
        results.vulnerabilities.authentication.found = true;
        results.vulnerabilities.authentication.details = (results.vulnerabilities.authentication.details || '') + 
          '\nFound "Remember Me" functionality that could potentially store authentication tokens insecurely';
      }
    }
    
    // 3. Check for Sensitive Data Exposure
    if (parsedUrl.protocol !== 'https:') {
      results.vulnerabilities.dataExposure.found = true;
      results.vulnerabilities.dataExposure.details = 'Website is not using HTTPS, which may lead to data exposure during transmission';
    }
    
    // Email addresses exposed in HTML 
    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const emails = response.data.match(emailRegex) || [];
    if (emails.length > 0) {
      results.vulnerabilities.dataExposure.found = true;
      results.vulnerabilities.dataExposure.details = (results.vulnerabilities.dataExposure.details || '') +
        `\nFound ${emails.length} email addresses exposed in the HTML: ${emails.slice(0, 3).join(', ')}${emails.length > 3 ? '...' : ''}`;
    }
    
    // 4. XXE - Limited passive detection capability
    const hasXmlUpload = $('input[type="file"]').filter((i, input) => {
      return $(input).attr('accept')?.includes('xml');
    }).length > 0;
    
    if (hasXmlUpload) {
      results.vulnerabilities.xxe.found = true;
      results.vulnerabilities.xxe.details = 'Found file upload that accepts XML files, which could be vulnerable to XXE attacks if not properly validated';
    }
    
    // 5. Broken Access Control - Limited passive detection
    const hasAdminLinks = $('a').filter((i, link) => {
      const href = $(link).attr('href') || '';
      const text = $(link).text().toLowerCase();
      return href.includes('admin') || href.includes('dashboard') || 
             text.includes('admin') || text.includes('dashboard');
    }).length > 0;
    
    if (hasAdminLinks) {
      results.vulnerabilities.accessControl.found = true;
      results.vulnerabilities.accessControl.details = 'Found links to administrative areas that may be accessible without proper authentication';
    }
    
    // 6. Security Misconfiguration
    let misconfigurations = [];
    
    // Check for missing security headers
    if (!securityHeaders['Content-Security-Policy']) {
      misconfigurations.push('Missing Content-Security-Policy header');
    }
    if (!securityHeaders['X-XSS-Protection']) {
      misconfigurations.push('Missing X-XSS-Protection header');
    }
    if (!securityHeaders['X-Frame-Options']) {
      misconfigurations.push('Missing X-Frame-Options header');
    }
    if (!securityHeaders['X-Content-Type-Options']) {
      misconfigurations.push('Missing X-Content-Type-Options header');
    }
    if (parsedUrl.protocol === 'https:' && !securityHeaders['Strict-Transport-Security']) {
      misconfigurations.push('Missing Strict-Transport-Security header (HSTS)');
    }
    
    // Check for server information disclosure
    if (responseHeaders['server']) {
      misconfigurations.push(`Server information disclosed: ${responseHeaders['server']}`);
    }
    
    if (misconfigurations.length > 0) {
      results.vulnerabilities.securityMisconfiguration.found = true;
      results.vulnerabilities.securityMisconfiguration.details = misconfigurations.join('\n');
    }
    
    // 7. Cross-Site Scripting (XSS)
    const xssVectors = [];
    
    // Check for reflected parameters
    const urlParams = new URLSearchParams(parsedUrl.search);
    for (const [param, value] of urlParams.entries()) {
      if (response.data.includes(value)) {
        xssVectors.push(`Parameter "${param}" is reflected in the response`);
      }
    }
    
    // Check for inputs without proper escaping 
    const suspiciousInputs = [];
    $('input').each((i, input) => {
      const type = $(input).attr('type') || '';
      const name = $(input).attr('name') || '';
      if (['text', 'search', 'url', 'textarea'].includes(type.toLowerCase())) {
        if (!name.match(/csrf|token|captcha/i)) {
          suspiciousInputs.push(name || `input-${i}`);
        }
      }
    });
    
    if (suspiciousInputs.length > 0) {
      xssVectors.push(`Found ${suspiciousInputs.length} inputs that might be vulnerable to XSS: ${suspiciousInputs.join(', ')}`);
    }
    
    if (xssVectors.length > 0) {
      results.vulnerabilities.xss.found = true;
      results.vulnerabilities.xss.details = xssVectors.join('\n');
    }
    
    // 8. Insecure Deserialization - Limited passive detection
    // Look for common serialization patterns in cookies
    const cookies = responseHeaders['set-cookie'] || [];
    let deserializationIssues = [];
    
    for (const cookie of cookies) {
      if (cookie.includes('O:') || cookie.includes('a:') || cookie.includes('s:') || cookie.includes('serialized=')) {
        deserializationIssues.push(`Found potentially serialized data in cookie: ${cookie.split(';')[0]}`);
      }
    }
    
    if (deserializationIssues.length > 0) {
      results.vulnerabilities.insecureDeserialization.found = true;
      results.vulnerabilities.insecureDeserialization.details = deserializationIssues.join('\n');
    }
    
    // 9. Using Components with Known Vulnerabilities
    // Check for outdated JavaScript libraries
    const jsLibraries = [];
    $('script').each((i, script) => {
      const src = $(script).attr('src') || '';
      if (src) {
        const jsLib = src.split('/').pop().split('?')[0];
        const versionMatch = src.match(/(\d+\.\d+\.\d+|\d+\.\d+)/);
        const version = versionMatch ? versionMatch[0] : 'unknown';
        
        if (jsLib && !src.includes('min.js') && src.includes('jquery')) {
          jsLibraries.push(`${jsLib} - v${version}`);
        }
      }
    });
    
    if (jsLibraries.length > 0) {
      results.vulnerabilities.vulnerableComponents.found = true;
      results.vulnerabilities.vulnerableComponents.details = `Detected JavaScript libraries that should be checked for vulnerabilities: ${jsLibraries.join(', ')}`;
    }
    
    // 10. Insufficient Logging & Monitoring
    // This is hard to detect passively, but we can check for indicators
    results.vulnerabilities.logging.found = true;
    results.vulnerabilities.logging.details = 'Cannot determine logging and monitoring mechanisms through passive scanning. Manual verification is recommended.';
    
    // Generate recommendations based on findings
    let recommendationsList = [];
    let criticalIssuesFound = 0;
    
    for (const key in results.vulnerabilities) {
      if (results.vulnerabilities[key].found) {
        criticalIssuesFound++;
        recommendationsList.push(`- ${results.vulnerabilities[key].name}: ${results.vulnerabilities[key].recommendation}`);
      }
    }
    
    results.recommendations = 'Based on the scan results, we recommend the following security improvements:\n\n' + 
                              recommendationsList.join('\n\n');
    
    // Generate conclusion
    if (criticalIssuesFound === 0) {
      results.conclusion = 'No critical security issues were detected during the scan. However, this does not guarantee that the website is completely secure. Regular security assessments and penetration testing are recommended.';
    } else if (criticalIssuesFound <= 3) {
      results.conclusion = `${criticalIssuesFound} potential security issues were identified. These should be addressed to improve the security posture of the website.`;
    } else {
      results.conclusion = `${criticalIssuesFound} potential security issues were identified, indicating significant security concerns. It is strongly recommended to address these issues as soon as possible.`;
    }
    
    console.log(`Scan completed for: ${targetUrl}`);
    
  } catch (error) {
    console.error(`Error scanning ${targetUrl}:`, error.message);
    
    // Still return a report with error information
    for (const key in results.vulnerabilities) {
      results.vulnerabilities[key].details = 'Scan failed to complete';
    }
    
    results.recommendations = 'The scan could not be completed due to technical issues. Please try again later or check if the target URL is accessible.';
    results.conclusion = `Error encountered during scanning: ${error.message}`;
  }
  
  return results;
}

module.exports = { performOWASPScan }; 