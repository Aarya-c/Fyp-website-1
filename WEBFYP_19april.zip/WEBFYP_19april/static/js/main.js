document.addEventListener('DOMContentLoaded', function() {
    // Initialize the accordion functionality
    initAccordion();
    
    // Initialize username display for dashboard pages
    initUsernameDisplay();
});

/**
 * Initialize accordion functionality for OWASP Top 10 section
 */
function initAccordion() {
    const accordionItems = document.querySelectorAll('.accordion-item');
    
    if (accordionItems.length === 0) return;
    
    // Add click event listeners to all accordion headers
    accordionItems.forEach(item => {
        const header = item.querySelector('.accordion-header');
        
        if (!header) return;
        
        header.addEventListener('click', () => {
            // Check if this item is already active
            const isActive = item.classList.contains('active');
            
            // Close all accordion items
            accordionItems.forEach(accItem => {
                accItem.classList.remove('active');
            });
            
            // If the clicked item wasn't active, activate it
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
    
    // Activate the first item by default
    if (accordionItems.length > 0) {
        accordionItems[0].classList.add('active');
    }
}

/**
 * Initialize username display in dashboard pages
 */
function initUsernameDisplay() {
    const usernameDisplay = document.getElementById('username-display');
    
    if (!usernameDisplay) return;
    
    // Make a request to get the current user info
    fetch('/auth/current-user')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.username) {
                usernameDisplay.textContent = data.username;
            }
        })
        .catch(error => {
            console.error('Error fetching user info:', error);
        });
} 