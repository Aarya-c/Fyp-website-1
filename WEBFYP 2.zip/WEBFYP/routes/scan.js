const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const { performOWASPScan } = require('../scripts/scanner');

// Start a new scan
router.post('/start', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }

  const { url } = req.body;
  
  if (!url) {
    return res.status(400).json({ success: false, message: 'URL is required' });
  }
  
  // Validate URL format
  try {
    new URL(url);
  } catch (err) {
    return res.status(400).json({ success: false, message: 'Invalid URL format' });
  }
  
  const scanId = uuidv4();
  const db = req.db;
  
  // Store scan in database
  db.run('INSERT INTO scans (id, user_id, url, status) VALUES (?, ?, ?, ?)', 
    [scanId, req.session.userId, url, 'in_progress'], async function(err) {
      if (err) {
        return res.status(500).json({ success: false, message: 'Server error' });
      }
      
      // Perform scan in background
      try {
        const scanResults = await performOWASPScan(url);
        
        // Store scan results
        const reportData = JSON.stringify(scanResults);
        const reportId = uuidv4();
        
        db.run('INSERT INTO reports (id, scan_id, report_data) VALUES (?, ?, ?)', 
          [reportId, scanId, reportData], function(err) {
            if (err) {
              console.error('Error storing report:', err);
            }
          });
        
        // Update scan status
        db.run('UPDATE scans SET status = ? WHERE id = ?', ['completed', scanId]);
        
      } catch (error) {
        console.error('Scan error:', error);
        db.run('UPDATE scans SET status = ? WHERE id = ?', ['failed', scanId]);
      }
    });
  
  res.json({ success: true, scanId, message: 'Scan started successfully' });
});

// Get scan status
router.get('/status/:scanId', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  
  const { scanId } = req.params;
  const db = req.db;
  
  db.get('SELECT * FROM scans WHERE id = ? AND user_id = ?', 
    [scanId, req.session.userId], (err, scan) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Server error' });
      }
      
      if (!scan) {
        return res.status(404).json({ success: false, message: 'Scan not found' });
      }
      
      res.json({ success: true, scan });
    });
});

// Get user's scan history with pagination and filtering
router.get('/history', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  
  const db = req.db;
  const page = parseInt(req.query.page) || 1;
  const limit = 10; // Items per page
  const offset = (page - 1) * limit;
  
  // Build query with filters
  let query = 'SELECT s.*, COUNT(r.id) as has_report FROM scans s LEFT JOIN reports r ON s.id = r.scan_id WHERE s.user_id = ?';
  let countQuery = 'SELECT COUNT(*) as total FROM scans WHERE user_id = ?';
  let queryParams = [req.session.userId];
  let countQueryParams = [req.session.userId];
  
  // URL filter
  if (req.query.url) {
    query += ' AND s.url LIKE ?';
    countQuery += ' AND url LIKE ?';
    const urlParam = `%${req.query.url}%`;
    queryParams.push(urlParam);
    countQueryParams.push(urlParam);
  }
  
  // Status filter
  if (req.query.status && ['completed', 'in_progress', 'failed', 'pending'].includes(req.query.status)) {
    query += ' AND s.status = ?';
    countQuery += ' AND status = ?';
    queryParams.push(req.query.status);
    countQueryParams.push(req.query.status);
  }
  
  // Date filter
  if (req.query.date) {
    let dateFilter = '';
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
    
    switch(req.query.date) {
      case 'today':
        dateFilter = ` AND s.scan_date >= '${today}'`;
        break;
      case 'week':
        const weekAgo = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7).toISOString();
        dateFilter = ` AND s.scan_date >= '${weekAgo}'`;
        break;
      case 'month':
        const monthAgo = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate()).toISOString();
        dateFilter = ` AND s.scan_date >= '${monthAgo}'`;
        break;
      case 'year':
        const yearAgo = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate()).toISOString();
        dateFilter = ` AND s.scan_date >= '${yearAgo}'`;
        break;
    }
    
    if (dateFilter) {
      query += dateFilter;
      countQuery += dateFilter;
    }
  }
  
  // Group by and add pagination
  query += ' GROUP BY s.id ORDER BY s.scan_date DESC LIMIT ? OFFSET ?';
  queryParams.push(limit, offset);
  
  // Execute count query to get total records
  db.get(countQuery, countQueryParams, (err, countResult) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Server error', error: err.message });
    }
    
    const total = countResult.total;
    const totalPages = Math.ceil(total / limit);
    
    // Execute main query
    db.all(query, queryParams, (err, scans) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Server error', error: err.message });
      }
      
      // For each scan with a report, get vulnerability count
      const processScans = [];
      let processed = 0;
      
      if (scans.length === 0) {
        return res.json({ 
          success: true, 
          scans: [], 
          page, 
          totalPages,
          totalItems: total
        });
      }
      
      scans.forEach(scan => {
        if (scan.has_report && scan.status === 'completed') {
          db.get('SELECT report_data FROM reports WHERE scan_id = ?', [scan.id], (err, report) => {
            if (!err && report) {
              try {
                const reportData = JSON.parse(report.report_data);
                const vulnerabilitiesFound = Object.values(reportData.vulnerabilities).filter(v => v.found).length;
                scan.vulnerability_count = vulnerabilitiesFound;
              } catch (e) {
                scan.vulnerability_count = 'N/A';
              }
            }
            
            processScans.push(scan);
            processed++;
            
            if (processed === scans.length) {
              return res.json({ 
                success: true, 
                scans: processScans, 
                page, 
                totalPages,
                totalItems: total
              });
            }
          });
        } else {
          processScans.push(scan);
          processed++;
          
          if (processed === scans.length) {
            return res.json({ 
              success: true, 
              scans: processScans, 
              page, 
              totalPages,
              totalItems: total
            });
          }
        }
      });
    });
  });
});

// Rescan URL from existing scan
router.post('/rescan/:scanId', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  
  const { scanId } = req.params;
  const db = req.db;
  
  // Check if scan exists and belongs to user
  db.get('SELECT * FROM scans WHERE id = ? AND user_id = ?', 
    [scanId, req.session.userId], async (err, scan) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Server error' });
      }
      
      if (!scan) {
        return res.status(404).json({ success: false, message: 'Scan not found' });
      }
      
      // Create a new scan with the same URL
      const newScanId = uuidv4();
      
      db.run('INSERT INTO scans (id, user_id, url, status) VALUES (?, ?, ?, ?)', 
        [newScanId, req.session.userId, scan.url, 'in_progress'], async function(err) {
          if (err) {
            return res.status(500).json({ success: false, message: 'Server error' });
          }
          
          // Perform scan in background
          try {
            const scanResults = await performOWASPScan(scan.url);
            
            // Store scan results
            const reportData = JSON.stringify(scanResults);
            const reportId = uuidv4();
            
            db.run('INSERT INTO reports (id, scan_id, report_data) VALUES (?, ?, ?)', 
              [reportId, newScanId, reportData], function(err) {
                if (err) {
                  console.error('Error storing report:', err);
                }
              });
            
            // Update scan status
            db.run('UPDATE scans SET status = ? WHERE id = ?', ['completed', newScanId]);
            
          } catch (error) {
            console.error('Scan error:', error);
            db.run('UPDATE scans SET status = ? WHERE id = ?', ['failed', newScanId]);
          }
        });
      
      res.json({ success: true, scanId: newScanId, message: 'Rescan started successfully' });
    });
});

module.exports = router; 