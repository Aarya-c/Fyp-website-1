const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

// Get report by ID
router.get('/:reportId', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  
  const { reportId } = req.params;
  const db = req.db;
  
  // Join reports with scans to ensure the user owns the report
  db.get(`
    SELECT r.* FROM reports r
    JOIN scans s ON r.scan_id = s.id
    WHERE r.id = ? AND s.user_id = ?
  `, [reportId, req.session.userId], (err, report) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
    
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }
    
    // Parse the report data
    const reportData = JSON.parse(report.report_data);
    
    res.json({ success: true, report: reportData });
  });
});

// Get report by scan ID
router.get('/scan/:scanId', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  
  const { scanId } = req.params;
  const db = req.db;
  
  // Join reports with scans to ensure the user owns the report
  db.get(`
    SELECT r.* FROM reports r
    JOIN scans s ON r.scan_id = s.id
    WHERE s.id = ? AND s.user_id = ?
  `, [scanId, req.session.userId], (err, report) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
    
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }
    
    // Parse the report data
    const reportData = JSON.parse(report.report_data);
    
    res.json({ success: true, report: reportData });
  });
});

// Download report as PDF
router.get('/download/:reportId', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  
  const { reportId } = req.params;
  const db = req.db;
  
  // Join reports with scans to ensure the user owns the report
  db.get(`
    SELECT r.*, s.url FROM reports r
    JOIN scans s ON r.scan_id = s.id
    WHERE r.id = ? AND s.user_id = ?
  `, [reportId, req.session.userId], (err, report) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
    
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }
    
    // Parse the report data
    const reportData = JSON.parse(report.report_data);
    const url = report.url;
    
    // Create a PDF document
    const doc = new PDFDocument();
    const filename = `owasp_scan_report_${Date.now()}.pdf`;
    
    // Set response headers
    res.setHeader('Content-disposition', `attachment; filename=${filename}`);
    res.setHeader('Content-type', 'application/pdf');
    
    // Pipe the PDF to the response
    doc.pipe(res);
    
    // Add content to the PDF
    doc.fontSize(20).text('OWASP Top 10 Vulnerability Scan Report', { align: 'center' });
    doc.moveDown();
    doc.fontSize(12).text(`URL: ${url}`);
    doc.moveDown();
    doc.text(`Report Date: ${new Date().toLocaleString()}`);
    doc.moveDown();
    
    // Add each vulnerability finding
    doc.fontSize(16).text('Findings Summary', { underline: true });
    doc.moveDown();
    
    Object.keys(reportData.vulnerabilities).forEach(vulnType => {
      const vuln = reportData.vulnerabilities[vulnType];
      doc.fontSize(14).text(vuln.name);
      doc.fontSize(12).text(`Status: ${vuln.found ? 'Vulnerable' : 'Not Vulnerable'}`);
      if (vuln.details) {
        doc.text(`Details: ${vuln.details}`);
      }
      if (vuln.recommendation) {
        doc.text(`Recommendation: ${vuln.recommendation}`);
      }
      doc.moveDown();
    });
    
    // Add recommendations and conclusion
    doc.fontSize(16).text('Recommendations', { underline: true });
    doc.moveDown();
    doc.fontSize(12).text(reportData.recommendations);
    doc.moveDown();
    
    doc.fontSize(16).text('Conclusion', { underline: true });
    doc.moveDown();
    doc.fontSize(12).text(reportData.conclusion);
    
    // Finalize the PDF
    doc.end();
  });
});

// Share report via email
router.post('/share/:reportId', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  
  const { reportId } = req.params;
  const { recipientEmail } = req.body;
  
  if (!recipientEmail) {
    return res.status(400).json({ success: false, message: 'Email address is required' });
  }
  
  const db = req.db;
  
  // Join reports with scans to ensure the user owns the report
  db.get(`
    SELECT r.*, s.url FROM reports r
    JOIN scans s ON r.scan_id = s.id
    WHERE r.id = ? AND s.user_id = ?
  `, [reportId, req.session.userId], async (err, report) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
    
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }
    
    // Parse the report data
    const reportData = JSON.parse(report.report_data);
    const url = report.url;
    
    // Create a PDF document
    const doc = new PDFDocument();
    const filename = `owasp_scan_report_${Date.now()}.pdf`;
    const tempFilePath = path.join(__dirname, '..', 'temp', filename);
    
    // Create temp directory if it doesn't exist
    if (!fs.existsSync(path.join(__dirname, '..', 'temp'))) {
      fs.mkdirSync(path.join(__dirname, '..', 'temp'));
    }
    
    // Pipe the PDF to a temporary file
    const writeStream = fs.createWriteStream(tempFilePath);
    doc.pipe(writeStream);
    
    // Add content to the PDF
    doc.fontSize(20).text('OWASP Top 10 Vulnerability Scan Report', { align: 'center' });
    doc.moveDown();
    doc.fontSize(12).text(`URL: ${url}`);
    doc.moveDown();
    doc.text(`Report Date: ${new Date().toLocaleString()}`);
    doc.moveDown();
    
    // Add each vulnerability finding
    doc.fontSize(16).text('Findings Summary', { underline: true });
    doc.moveDown();
    
    Object.keys(reportData.vulnerabilities).forEach(vulnType => {
      const vuln = reportData.vulnerabilities[vulnType];
      doc.fontSize(14).text(vuln.name);
      doc.fontSize(12).text(`Status: ${vuln.found ? 'Vulnerable' : 'Not Vulnerable'}`);
      if (vuln.details) {
        doc.text(`Details: ${vuln.details}`);
      }
      if (vuln.recommendation) {
        doc.text(`Recommendation: ${vuln.recommendation}`);
      }
      doc.moveDown();
    });
    
    // Add recommendations and conclusion
    doc.fontSize(16).text('Recommendations', { underline: true });
    doc.moveDown();
    doc.fontSize(12).text(reportData.recommendations);
    doc.moveDown();
    
    doc.fontSize(16).text('Conclusion', { underline: true });
    doc.moveDown();
    doc.fontSize(12).text(reportData.conclusion);
    
    // Finalize the PDF
    doc.end();
    
    // Wait for the PDF to be created
    writeStream.on('finish', async () => {
      try {
        // Create a test account on Ethereal Email for testing
        const testAccount = await nodemailer.createTestAccount();
        
        // Create a transporter (in production, use your actual SMTP settings)
        const transporter = nodemailer.createTransport({
          host: 'smtp.ethereal.email',
          port: 587,
          secure: false,
          auth: {
            user: testAccount.user,
            pass: testAccount.pass
          }
        });
        
        // Send mail with defined transport object
        const info = await transporter.sendMail({
          from: '"OWASP Scanner" <scanner@example.com>',
          to: recipientEmail,
          subject: 'OWASP Vulnerability Scan Report',
          text: `Please find attached the OWASP Top 10 vulnerability scan report for ${url}`,
          attachments: [
            {
              filename: 'owasp_scan_report.pdf',
              path: tempFilePath
            }
          ]
        });
        
        // Remove the temporary file
        fs.unlinkSync(tempFilePath);
        
        // Log the Ethereal URL for testing purposes
        console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
        
        res.json({ 
          success: true, 
          message: 'Report sent successfully',
          previewUrl: nodemailer.getTestMessageUrl(info)
        });
      } catch (error) {
        console.error('Email sending error:', error);
        // Remove the temporary file if it exists
        if (fs.existsSync(tempFilePath)) {
          fs.unlinkSync(tempFilePath);
        }
        res.status(500).json({ success: false, message: 'Failed to send email' });
      }
    });
  });
});

module.exports = router; 