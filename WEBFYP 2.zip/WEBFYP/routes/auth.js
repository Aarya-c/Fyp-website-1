const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const path = require('path');

// Login page route
router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'templates/login.html'));
});

// Register page route
router.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'templates/register.html'));
});

// Get current user info
router.get('/current-user', (req, res) => {
  if (!req.session.userId) {
    return res.json({ success: false, message: 'Not authenticated' });
  }
  
  res.json({
    success: true,
    userId: req.session.userId,
    username: req.session.username
  });
});

// Get user info for dashboard
router.get('/user-info', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Not authenticated' });
  }
  
  const db = req.db;
  
  db.get('SELECT id, username, email, profile_picture FROM users WHERE id = ?', 
    [req.session.userId], (err, user) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Server error' });
      }
      
      if (!user) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
      
      res.json({ success: true, user });
    });
});

// Register user
router.post('/register', async (req, res) => {
  const { username, email, password } = req.body;
  
  if (!username || !email || !password) {
    return res.status(400).json({ success: false, message: 'All fields are required' });
  }
  
  const db = req.db;
  
  // Check if user already exists
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
    
    if (user) {
      return res.status(400).json({ success: false, message: 'User already exists' });
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Insert new user
    db.run('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
      [username, email, hashedPassword], function(err) {
        if (err) {
          return res.status(500).json({ success: false, message: 'Server error' });
        }
        
        // Create session
        req.session.userId = this.lastID;
        req.session.username = username;
        
        res.status(201).json({ success: true, userId: this.lastID, redirect: '/dashboard' });
      });
  });
});

// Login user
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required' });
  }
  
  const db = req.db;
  
  // Find user
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
    
    if (!user) {
      return res.status(400).json({ success: false, message: 'Invalid credentials' });
    }
    
    // Check if user has a password (might be Google user)
    if (!user.password) {
      return res.status(400).json({ 
        success: false, 
        message: 'This account was created with Google. Please login with Google.'
      });
    }
    
    // Compare password
    const isMatch = await bcrypt.compare(password, user.password);
    
    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'Invalid credentials' });
    }
    
    // Create session
    req.session.userId = user.id;
    req.session.username = user.username;
    
    res.json({ success: true, userId: user.id, redirect: '/dashboard' });
  });
});

// Logout user
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

module.exports = router; 