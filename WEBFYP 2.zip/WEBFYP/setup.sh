#!/bin/bash

echo "OWASP Scanner Setup"
echo "==================="

echo "Checking for Node.js..."
if ! command -v node &> /dev/null; then
    echo "Node.js is not installed."
    echo "Please install Node.js from https://nodejs.org/"
    echo "After installation, run this script again."
    exit 1
fi

echo "Installing dependencies..."
npm install

echo
echo "Setup complete!"
echo
echo "To start the application in development mode, run:"
echo "    npm run dev"
echo
echo "To start the application in production mode, run:"
echo "    npm start"
echo
echo "You can then access the application at http://localhost:3000" 