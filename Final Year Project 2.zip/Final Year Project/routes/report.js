const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const { sendEmail } = require('../config/email');

// Create PDF
function createPDF(reportData, url, filepath) {
    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument();
            const stream = fs.createWriteStream(filepath);
            
            // Handle stream errors
            stream.on('error', (error) => {
                console.error('Stream error:', error);
                reject(error);
            });

            doc.pipe(stream);

            // Add content to PDF
            doc.fontSize(20).text('OWASP Top 10 Vulnerability Scan Report', { align: 'center' });
            doc.moveDown();
            doc.fontSize(12).text(`URL: ${url}`);
            doc.text(`Generated on: ${new Date().toLocaleString()}`);
            doc.moveDown();
            doc.fontSize(16).text('Findings Summary', { underline: true });

            Object.values(reportData.vulnerabilities).forEach(vuln => {
                doc.moveDown().fontSize(14).text(vuln.name);
                doc.fontSize(12).text(`Status: ${vuln.found ? 'Vulnerable' : 'Not Vulnerable'}`);
                if (vuln.details) doc.text(`Details: ${vuln.details}`);
                if (vuln.recommendation) doc.text(`Recommendation: ${vuln.recommendation}`);
            });

            doc.moveDown().fontSize(16).text('Recommendations', { underline: true });
            doc.fontSize(12).text(reportData.recommendations);
            doc.moveDown().fontSize(16).text('Conclusion', { underline: true });
            doc.fontSize(12).text(reportData.conclusion);

            // Handle document completion
            doc.end();

            stream.on('finish', () => {
                console.log('PDF created successfully at:', filepath);
                resolve(filepath);
            });
        } catch (error) {
            console.error('Error creating PDF:', error);
            reject(error);
        }
    });
}

// Share Report by Scan ID
router.post('/share/scan/:scanId', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ success: false, message: 'Authentication required' });
    }

    const { scanId } = req.params;
    const { recipientEmail } = req.body;

    console.log('Share report request:', { scanId, recipientEmail, userId: req.session.userId });

    if (!recipientEmail) {
        return res.status(400).json({ success: false, message: 'Recipient email is required' });
    }

    const db = req.db;
    try {
        const report = await new Promise((resolve, reject) => {
            db.get(
                `SELECT r.*, s.url FROM reports r 
                JOIN scans s ON r.scan_id = s.id 
                WHERE s.id = ? AND s.user_id = ?`,
                [scanId, req.session.userId],
                (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                }
            );
        });

        if (!report) {
            return res.status(404).json({ success: false, message: 'Report not found' });
        }

        const reportData = JSON.parse(report.report_data);
        const tempDir = path.join(__dirname, '..', 'temp');
        
        // Ensure temp directory exists
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }

        const filepath = path.join(tempDir, `report_${Date.now()}.pdf`);
        
        try {
            // Create PDF
            await createPDF(reportData, report.url, filepath);

            // Send email with PDF attachment
            const emailResult = await sendEmail(
                recipientEmail,
                'OWASP Vulnerability Scan Report',
                `Please find attached the vulnerability scan report for ${report.url}\n\nThis report was generated on ${new Date().toLocaleString()}`,
                [{
                    filename: 'vulnerability_report.pdf',
                    path: filepath,
                    contentType: 'application/pdf'
                }]
            );

            // Clean up the temporary file
            if (fs.existsSync(filepath)) {
                fs.unlinkSync(filepath);
                console.log('Temporary PDF file cleaned up');
            }

            if (emailResult.success) {
                console.log('Email sent successfully:', emailResult);
                res.json({ 
                    success: true, 
                    message: 'Report sent successfully',
                    messageId: emailResult.messageId
                });
            } else {
                console.error('Email sending failed:', emailResult.error);
                res.status(500).json({ 
                    success: false, 
                    message: 'Failed to send report: ' + emailResult.error 
                });
            }
        } catch (error) {
            console.error('Error in PDF creation or email sending:', error);
            // Clean up the temporary file in case of error
            if (fs.existsSync(filepath)) {
                fs.unlinkSync(filepath);
                console.log('Temporary PDF file cleaned up after error');
            }
            res.status(500).json({ 
                success: false, 
                message: 'Error processing report: ' + error.message 
            });
        }
    } catch (error) {
        console.error('Database error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Database error: ' + error.message 
        });
    }
});

// Download PDF by Scan ID
router.get('/download/pdf/scan/:scanId', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ success: false, message: 'Authentication required' });
  const { scanId } = req.params;
  const db = req.db;

  db.get(`SELECT r.*, s.url FROM reports r JOIN scans s ON r.scan_id = s.id WHERE s.id = ? AND s.user_id = ?`,
    [scanId, req.session.userId], (err, report) => {
      if (err || !report) return res.status(404).json({ success: false, message: 'Report not found' });

      const reportData = JSON.parse(report.report_data);
      res.setHeader('Content-disposition', `attachment; filename=owasp_scan_report_${Date.now()}.pdf`);
      res.setHeader('Content-type', 'application/pdf');

      const doc = new PDFDocument();
      doc.pipe(res);

      doc.fontSize(20).text('OWASP Top 10 Vulnerability Scan Report', { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`URL: ${report.url}`);
      doc.moveDown();
      doc.text(`Report Date: ${new Date().toLocaleString()}`);
      doc.moveDown();

      doc.fontSize(16).text('Findings Summary', { underline: true });
      doc.moveDown();
      Object.keys(reportData.vulnerabilities).forEach(vulnType => {
        const vuln = reportData.vulnerabilities[vulnType];
        doc.fontSize(14).text(vuln.name);
        doc.fontSize(12).text(`Status: ${vuln.found ? 'Vulnerable' : 'Not Vulnerable'}`);
        if (vuln.details) doc.text(`Details: ${vuln.details}`);
        if (vuln.recommendation) doc.text(`Recommendation: ${vuln.recommendation}`);
        doc.moveDown();
      });

      doc.fontSize(16).text('Recommendations', { underline: true });
      doc.moveDown();
      doc.fontSize(12).text(reportData.recommendations);
      doc.moveDown();
      doc.fontSize(16).text('Conclusion', { underline: true });
      doc.moveDown();
      doc.fontSize(12).text(reportData.conclusion);
      doc.end();
    });
});

// Download JSON by Scan ID
router.get('/download/json/scan/:scanId', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ success: false, message: 'Authentication required' });
  const { scanId } = req.params;
  const db = req.db;

  db.get(`SELECT r.*, s.url FROM reports r JOIN scans s ON r.scan_id = s.id WHERE s.id = ? AND s.user_id = ?`,
    [scanId, req.session.userId], (err, report) => {
      if (err || !report) return res.status(404).json({ success: false, message: 'Report not found' });

      const reportData = JSON.parse(report.report_data);
      reportData.url = report.url;
      reportData.reportId = report.id;
      reportData.scanId = report.scan_id;
      reportData.exportDate = new Date().toISOString();

      const filename = `owasp_scan_report_${Date.now()}.json`;
      res.setHeader('Content-disposition', `attachment; filename=${filename}`);
      res.setHeader('Content-type', 'application/json');
      res.json(reportData);
    });
});

// Get Report by Scan ID
router.get('/scan/:scanId', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ success: false, message: 'Authentication required' });
  const { scanId } = req.params;
  const db = req.db;

  db.get(`SELECT r.*, s.url FROM reports r JOIN scans s ON r.scan_id = s.id WHERE s.id = ? AND s.user_id = ?`,
    [scanId, req.session.userId], (err, report) => {
      if (err) return res.status(500).json({ success: false, message: 'Database error' });
      if (!report) return res.status(404).json({ success: false, message: 'Report not found' });

      const reportData = JSON.parse(report.report_data);
      reportData.url = report.url;
      res.json({ success: true, report: reportData });
    });
});

module.exports = router;
