const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const path = require('path');

// Login page route
router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'templates/login.html'));
});

// Register page route
router.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'templates/register.html'));
});

// Get current user info
router.get('/current-user', (req, res) => {
  if (!req.session.userId) {
    return res.json({ success: false, message: 'Not authenticated' });
  }
  
  res.json({
    success: true,
    userId: req.session.userId,
    username: req.session.username
  });
});

// Get user info for dashboard
router.get('/user-info', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Not authenticated' });
  }
  
  const db = req.db;
  
  db.get('SELECT id, username, email, profile_picture FROM users WHERE id = ?', 
    [req.session.userId], (err, user) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Server error' });
      }
      
      if (!user) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
      
      res.json({ success: true, user });
    });
});

// Register user
router.post('/register', async (req, res) => {
  try {
    console.log('Registration attempt:', { ...req.body, password: '[REDACTED]' });
    
    const { username, email, password } = req.body;
    
    if (!username || !email || !password) {
      console.log('Missing required fields:', { username: !!username, email: !!email, password: !!password });
      return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      console.log('Invalid email format:', email);
      return res.status(400).json({ success: false, message: 'Invalid email format' });
    }

    // Validate password strength
    if (password.length < 8) {
      console.log('Password too short');
      return res.status(400).json({ success: false, message: 'Password must be at least 8 characters long' });
    }
    
    const db = req.db;
    
    if (!db) {
      console.error('Database connection not available');
      return res.status(500).json({ success: false, message: 'Database connection error' });
    }
    
    // Check if user already exists
    db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
      if (err) {
        console.error('Database error during user check:', err);
        return res.status(500).json({ success: false, message: 'Server error' });
      }
      
      if (user) {
        console.log('User already exists:', email);
        return res.status(400).json({ success: false, message: 'User already exists' });
      }
      
      try {
        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);
        
        console.log('Attempting to insert new user:', { username, email });
        
        // Insert new user
        db.run('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
          [username, email, hashedPassword], function(err) {
            if (err) {
              console.error('Database error during user insertion:', err);
              return res.status(500).json({ success: false, message: 'Server error' });
            }
            
            console.log('User successfully created:', { id: this.lastID, username });
            
            // Create session
            req.session.userId = this.lastID;
            req.session.username = username;
            
            res.status(201).json({ success: true, userId: this.lastID, redirect: '/dashboard' });
          });
      } catch (err) {
        console.error('Bcrypt error:', err);
        return res.status(500).json({ success: false, message: 'Error creating user' });
      }
    });
  } catch (err) {
    console.error('Registration error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Login user
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required' });
  }
  
  const db = req.db;
  
  // Find user
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Server error' });
    }
    
    if (!user) {
      return res.status(400).json({ success: false, message: 'Invalid credentials' });
    }
    
    // Check if user has a password (might be Google user)
    if (!user.password) {
      return res.status(400).json({ 
        success: false, 
        message: 'This account was created with Google. Please login with Google.'
      });
    }
    
    // Compare password
    const isMatch = await bcrypt.compare(password, user.password);
    
    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'Invalid credentials' });
    }
    
    // Create session
    req.session.userId = user.id;
    req.session.username = user.username || email.split('@')[0];
    
    res.json({ success: true, userId: user.id, redirect: '/dashboard' });
  });
});

// Logout user
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

module.exports = router; 