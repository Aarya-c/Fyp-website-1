const nodemailer = require('nodemailer');
const fs = require('fs');

// Create reusable transporter object using Gmail SMTP
const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true, // use SSL
    auth: {
        user: 'Aaryachaudhary466@gmail.com',
        pass: 'tzsb evbe vlww vhpi' // your app password
    },
    tls: {
        rejectUnauthorized: false
    }
});

// Verify transporter configuration
transporter.verify(function(error, success) {
    if (error) {
        console.error('Email transporter verification failed:', error);
    } else {
        console.log('Email transporter is ready to send messages');
    }
});

// Function to send email
async function sendEmail(to, subject, text, attachments = []) {
    try {
        console.log('Preparing to send email:', {
            to,
            subject,
            hasAttachments: attachments.length > 0
        });

        // Validate email address
        if (!to || typeof to !== 'string' || !to.includes('@')) {
            throw new Error('Invalid recipient email address');
        }

        // Check for attachments existence
        if (attachments.length > 0) {
            for (const attachment of attachments) {
                if (attachment.path && !fs.existsSync(attachment.path)) {
                    throw new Error(`Attachment file not found: ${attachment.path}`);
                }
            }
        }

        const mailOptions = {
            from: {
                name: 'OWASP Scanner',
                address: 'Aaryachaudhary466@gmail.com'
            },
            to,
            subject,
            text,
            attachments,
            priority: 'high'
        };

        console.log('Sending email with options:', {
            to: mailOptions.to,
            subject: mailOptions.subject,
            hasAttachments: mailOptions.attachments.length > 0
        });

        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent successfully:', {
            messageId: info.messageId,
            response: info.response,
            accepted: info.accepted,
            rejected: info.rejected
        });
        
        return { 
            success: true, 
            messageId: info.messageId,
            response: info.response 
        };
    } catch (error) {
        console.error('Error sending email:', {
            error: error.message,
            stack: error.stack,
            code: error.code,
            command: error.command
        });
        return { 
            success: false, 
            error: error.message,
            code: error.code 
        };
    }
}

module.exports = { sendEmail }; 