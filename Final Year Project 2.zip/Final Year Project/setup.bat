@echo off
echo OWASP Scanner Setup
echo ===================

echo Checking for Node.js...
where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Node.js is not installed or not in your PATH.
    echo Please install Node.js from https://nodejs.org/
    echo After installation, run this script again.
    pause
    exit /b
)

echo Installing dependencies...
npm install

echo.
echo Setup complete!
echo.
echo To start the application in development mode, run:
echo     npm run dev
echo.
echo To start the application in production mode, run:
echo     npm start
echo.
echo You can then access the application at http://localhost:3000

pause 